(function() {
  window._POSTHOG_REMOTE_CONFIG = window._POSTHOG_REMOTE_CONFIG || {};
  window._POSTHOG_REMOTE_CONFIG['phc_w63zR5rn35AzyiKmQ6sKiR8fwYsM46q4WaiHahwkYII'] = {
    config: {"token": "phc_w63zR5rn35AzyiKmQ6sKiR8fwYsM46q4WaiHahwkYII", "supportedCompression": ["gzip", "gzip-js"], "hasFeatureFlags": true, "captureDeadClicks": false, "capturePerformance": {"network_timing": true, "web_vitals": false, "web_vitals_allowed_metrics": null}, "autocapture_opt_out": false, "autocaptureExceptions": false, "analytics": {"endpoint": "/i/v0/e/"}, "elementsChainAsString": true, "errorTracking": {"autocaptureExceptions": false, "suppressionRules": []}, "sessionRecording": false, "heatmaps": false, "surveys": false, "defaultIdentifiedOnly": true},
    siteApps: []
  }
})();